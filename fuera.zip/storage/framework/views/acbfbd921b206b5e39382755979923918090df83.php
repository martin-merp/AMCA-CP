



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Gestión Vegetales</div>

                <div class="card-body">
                    <input type="button" class="btn btn-success mb-2 float-right" data-toggle="modal" data-target="#registro" value="Nuevo"
                    onclick="
                        document.getElementById('especie').value='';
                        document.getElementById('cultivo').value='';                     
                        document.getElementById('observaciones').value='';
                        document.getElementById('id_edita').value='">
                    <table class="table table-striped table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th>#</th><th>Especie</th><th>Imagen</th><th>Cultivo</th><th></th>
                            </tr>
                        <thead>
                        <tbody>
                        <?php $cont = 0; ?>
                        <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vegetal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $cont++; ?>
                            <tr>
                                <td><?php echo e($cont); ?></td>
                                <td><?php echo e($vegetal->especie); ?></td>
                                <td><img style="max-width: 2em;" src="img/vegetales/<?php echo e($vegetal->imagen); ?>"></td>
                                <td><?php echo e($vegetal->cultivo); ?></td>
                                <td >

                                    <input type="button" class="btn btn-success float-right mr-2" data-toggle="modal" data-target="#registro" value="Editar" onclick="
                                        document.getElementById('especie').value='<?php echo e($vegetal->especie); ?>';
                                        document.getElementById('cultivo').value='<?php echo e($vegetal->cultivo); ?>';
                                        document.getElementById('observaciones').value='<?php echo e($vegetal->observaciones); ?>';
                                        document.getElementById('id_edita').value='<?php echo e($vegetal->id); ?>';">

                                <form method="POST" action="<?php echo e(route('vegetales_eliminar')); ?>" onsubmit="if(!confirm('esta seguro de eliminar este registro')){ return false;}">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id_elimina" value="<?php echo e($vegetal->id); ?>">
                                        <input type="submit" class="btn btn-danger float-right mr-2" value="Eliminar">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="registro" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Datos Vegetal</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form method="POST" action="<?php echo e(route('vegetales_guardar')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id_edita" id="id_edita">
                <div class="modal-body">
                
                    <div class="form-group row">
                      <label for="especie" class="col-sm-2 col-form-label">Especie*</label>
                      <div class="col-sm-4">
                        <input type="text" class="form-control" id="especie" name="especie" value="" required>
                      </div>                      
                    </div>
                    <div class="form-group row">
                        <label for="cultivo" class="col-sm-2 col-form-label" required>Cultivo*</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" id="cultivo" name="cultivo" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="observaciones" class="col-sm-2 col-form-label" required>Observación*</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" id="observaciones" name="observaciones" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="imagen">Imagen*</label>                    
                        <div class="col-sm-10">    
                            <input type="file" style="padding-bottom: 2.5em !important" class="form-control mt-2 mb-2" id="imagen" name="imagen">
                        </div>
                    </div>                
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </form>
          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amca\resources\views/vegetales.blade.php ENDPATH**/ ?>