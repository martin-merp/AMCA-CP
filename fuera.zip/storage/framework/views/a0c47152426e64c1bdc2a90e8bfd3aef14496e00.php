



<?php $__env->startSection('content'); ?>

<!--CARRUCEL DE IMAGENES-->

<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/animales/vacas-fooster.jpg" class="d-block w-100" style="max-height: 395px;" alt="">
      <div class="carousel-caption d-none d-md-block">
        <h1 style="font-size: 101px;">First slide label</h1>
        <p style="font-size: 21px;">Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/vegetales/aguacate-silvestre.jpg" class="d-block w-100" style="max-height: 395px;" alt="">
      <div class="carousel-caption d-none d-md-block">
        <h1 style="font-size: 101px;">Second slide label</h1>
        <p style="font-size: 21px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/preparados/embuelto-choclos.jpg" class="d-block w-100" style="max-height: 395px;" alt="">
      <div class="carousel-caption d-none d-md-block">
        <h1 style="font-size: 101px;">Third slide label</h1>
        <p style="font-size: 21px;">Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/finca/finca8.jpg" class="d-block w-100" style="max-height: 395px;" alt="">
      <div class="carousel-caption d-none d-md-block">
        <h1 style="font-size: 101px;">Third slide label</h1>
        <p style="font-size: 21px;">Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/agricultores/agricultor8.jpg" class="d-block w-100" style="max-height: 395px;" alt="">
      <div class="carousel-caption d-none d-md-block">
        <h1 style="font-size: 101px;">Third slide label</h1>
        <p style="font-size: 21px;">Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<?php //echo "<pre>"; print_r($animales); echo "</pre>";
?>
<!--/CARRUCEL DE IMAGENES-->

<!---TITULOS VEGETALES-->
<div class="container">
    <div class="row">
      <div class="col text-center text-uppercase">
        <small>Conoce nuetros</small>
        <h2>VEGETALES</h2>
      </div>
    </div>
</div>
<!---/TITULOS-->

<!--CARRUCEL CARDS-->
<div class="container">
  <div class="row">
    <?php $cont=1; ?>
    <?php $__currentLoopData = $vegetales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        <div class="col-md-3 " style="float:left">            
            <div class="card mb-2">
              <a href="pagina_detalle/<?php echo e($veg->id); ?>/vegetal" style="text-decoration: none;color: white;">
                <img class="card-img-top mb-2"                  
                src="img/vegetales/<?php echo e($veg->imagen); ?>" alt="Card image cap">
              </a>
              <div class="card-body  bg-secondary text-decoration-none" style="max-height: 9em; min-height: 9em; overflow-y: hidden;">
                <a href="pagina_detalle/<?php echo e($veg->id); ?>/vegetal" style="text-decoration: none;color: white;">
                  <h4 class="card-title text-decoration-none"><b><?php echo e($veg->especie); ?></b></h4>
                  <p class="card-text text-decoration-none"><?php echo e($veg->observaciones); ?></p>                  
                </a>
              </div>              
            </div>         
        </div>      
      <?php $cont++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>

<!--/CARRUCEL CARDS-->

<!---TITULOS 2 ANIMALES-->
<div class="container">
    <div class="row">
      <div class="col text-center text-uppercase">
        <small>Conoce nuetros</small>
        <h2>ANIMALES</h2>
      </div>
    </div>
</div>
<!---/TITULOS 2-->

<!--CARRUCEL CARDS 2 ANIMALES-->
<div class="container">
  <div class="row">
    <?php $cont=1; ?>
    <?php $__currentLoopData = $animales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        <div class="col-md-3 " style="float:left">            
            <div class="card mb-2">
              <a href="pagina_detalle/<?php echo e($anm->id); ?>/animal" style="text-decoration: none;color: white;">
                <img class="card-img-top mb-2"                  
                src="img/animales/<?php echo e($anm->imagen); ?>" alt="Card image cap">
              </a>
              <div class="card-body  bg-secondary text-decoration-none" style="max-height: 9em; min-height: 9em; overflow-y: hidden;">
                <a href="pagina_detalle/<?php echo e($anm->id); ?>/vegetal" style="text-decoration: none;color: white;">
                  <h4 class="card-title text-decoration-none"><b><?php echo e($anm->especie); ?></b></h4>
                  <p class="card-text text-decoration-none"><?php echo e($anm->observaciones); ?></p>                  
                </a>
              </div>              
            </div>         
        </div>      
      <?php $cont++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<!--/CARRUCEL CARDS 2--> 

<!---TITULOS 3 PREPARADOS-->
<div class="container">
    <div class="row">
      <div class="col text-center text-uppercase">
        <small>Conoce nuetros</small>
        <h2>PREPARADOS</h2>
      </div>
    </div>
</div>
<!---/TITULOS 3-->

<!--CARRUCEL CARDS 3-->
<div class="container">
  <div class="row">
    <?php $cont=1; ?>
    <?php $__currentLoopData = $preparados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        <div class="col-md-3 " style="float:left">            
            <div class="card mb-2">
              <a href="pagina_detalle/<?php echo e($pre->id); ?>/preparado" style="text-decoration: none;color: white;">
                <img class="card-img-top mb-2"                  
                src="img/preparados/<?php echo e($pre->imagen); ?>" alt="Card image cap">
              </a>
              <div class="card-body  bg-secondary text-decoration-none" style="max-height: 9em; min-height: 9em; overflow-y: hidden;">
                <a href="pagina_detalle/<?php echo e($pre->id); ?>/preparado" style="text-decoration: none;color: white;">
                  <h4 class="card-title text-decoration-none"><b><?php echo e($pre->nombre); ?></b></h4>
                  <p class="card-text text-decoration-none"><?php echo e($pre->observaciones); ?></p>                  
                </a>
              </div>              
            </div>         
        </div>      
      <?php $cont++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<!--/CARRUCEL CARDS 3-->

<!---TITULOS 4 AGRICULTORES-->
<div class="container">
  <div class="row">
    <div class="col text-center text-uppercase">
      <small>Conoce nuetros</small>
      <h2>AGRICULTORES</h2>
    </div>
  </div>
</div>
<!---/TITULOS 4-->

<!--CARRUCEL CARDS 4-->
<div class="container">
  <div class="row">
    <?php $cont=1; ?>
    <?php $__currentLoopData = $agricultores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        <div class="col-md-3 " style="float:left">            
            <div class="card mb-2">
              <a href="pagina_detalle/<?php echo e($agr->id); ?>/agricultor" style="text-decoration: none;color: white;">
                <img class="card-img-top mb-2"                  
                src="img/agricultores/<?php echo e($agr->imagen); ?>" alt="Card image cap">
              </a>
              <div class="card-body  bg-secondary text-decoration-none" style="max-height: 9em; min-height: 9em; overflow-y: hidden;">
                <a href="pagina_detalle/<?php echo e($agr->id); ?>/agicultores" style="text-decoration: none;color: white;">
                  <h4 class="card-title text-decoration-none"><b><?php echo e($agr->nombres); ?></b></h4>
                  <p class="card-text text-decoration-none"><?php echo e($agr->telefono); ?></p>                  
                </a>
              </div>              
            </div>         
        </div>      
      <?php $cont++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<!--/CARRUCEL CARDS 4-->

<!---TITULOS 5 FINCAS-->
<div class="container">
  <div class="row">
    <div class="col text-center text-uppercase">
      <small>Conoce nuetras</small>
      <h2>FINCAS</h2>
    </div>
  </div>
</div>
<!---/TITULOS 5-->

<!--CARRUCEL CARDS 5-->
<div class="container">
  <div class="row">
    <?php $cont=1; ?>
    <?php $__currentLoopData = $fincas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>      
        <div class="col-md-3 " style="float:left">            
            <div class="card mb-2">
              <a href="pagina_detalle/<?php echo e($fin->id); ?>/finca" style="text-decoration: none;color: white;">
                <img class="card-img-top mb-2"                  
                src="img/finca
                /<?php echo e($fin->imagen); ?>" alt="Card image cap">
              </a>
              <div class="card-body  bg-secondary text-decoration-none" style="max-height: 9em; min-height: 9em; overflow-y: hidden;">
                <a href="pagina_detalle/<?php echo e($fin->id); ?>/finca" style="text-decoration: none;color: white;">
                  <h4 class="card-title text-decoration-none"><b><?php echo e($fin->nombre); ?></b></h4>
                  <p class="card-text text-decoration-none"><?php echo e($fin->ubicacion); ?></p>                  
                </a>
              </div>              
            </div>         
        </div>      
      <?php $cont++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<!--/CARRUCEL CARDS 5-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amca\resources\views/paginaHome.blade.php ENDPATH**/ ?>