



<?php $__env->startSection('content'); ?>

<!--CARRUCEL DE IMAGENES-->


<?php //echo "<pre>"; print_r($aux_listado); echo "</pre>"; 
?>
<div class="container-xl mx-auto">
  <br>
  <div class="card mb-3 mx-auto" >
    <div class="row no-gutters">
      <div class="col-md-4">
        <br>
        <img src="<?php echo e(url('/')); ?>/<?php echo e($detalle['imagen']); ?>" class="card-img ml-4 mb-4" alt="...">
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title"><b><?php echo e(strtoupper($detalle['titulo'])); ?></b></h5>
          <p class="card-text">
              <?php print($detalle['texto']); ?>
          </p>          
        </div>
      </div>
    </div>
  </div>
</div> 

<div class="container-xl mx-auto">
  
  <div class="row">
    <?php if(count($aux_listado)>0): ?> 
      <div class="col-md-5 col-10 m-4 ">
        <div class="list-group">
          <div class="list-group-item list-group-item-action active">
            <div class="d-flex w-100 justify-content-between">
              <h5 class="mb-1"><?php echo e(strtoupper($titulo1)); ?></h5>            
            </div>         
          </div>
          <?php $__currentLoopData = $aux_listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('/')); ?>/pagina_detalle/<?php echo e($a_l['id']); ?>/<?php echo e($a_l['tipo']); ?>" class="list-group-item list-group-item-action">
              <div class="d-flex w-100 justify-content-between">
                <h5 class="mb-1"><?php echo e($a_l['nombre']); ?></h5>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    <?php endif; ?>
    <?php if(count($aux_listado2)>0): ?> 
      <div class="col-md-5 col-10 m-4 ">
        <div class="list-group">
          <div class="list-group-item list-group-item-action active">
            <div class="d-flex w-100 justify-content-between">
              <h5 class="mb-1"><?php echo e(strtoupper($titulo2)); ?></h5>            
            </div>         
          </div>
          <?php $__currentLoopData = $aux_listado2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a_l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('/')); ?>/pagina_detalle/<?php echo e($a_l['id']); ?>/<?php echo e($a_l['tipo']); ?>" class="list-group-item list-group-item-action">
              <div class="d-flex w-100 justify-content-between">
                <h5 class="mb-1"><?php echo e($a_l['nombre']); ?></h5>
              </div>
            </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\amca\resources\views/paginaDetalles.blade.php ENDPATH**/ ?>