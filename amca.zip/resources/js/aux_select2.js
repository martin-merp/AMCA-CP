$(document).ready(function() {
    $('.js-example-basic-multiple').select2();

   
});

function cargar_fincas(id_agricultor) {
    alert('aaaaa bbbb '+ id_agricultor);
}
